class Context:
    def __init__(self, source_path, file_types):
        self.source_path = source_path
        self.file_types = file_types


