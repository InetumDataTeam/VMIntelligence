class Traitement:
    def init(self, data: dict, filename: str) -> dict:
        pass
